<div class="container main-content clearfix">

     <div class="featured-clients clearfix bottom-2">
       <div class="slidewrap4" >
    
        <div class="sixteen columns"> 
         <h3 class="title bottom-2">Featured Clients</h3> 
        </div>
        
        <ul class="slider" id="sliderName4">
          <li class="slide">
           <div class="four columns item"><a href="#"><img src="images/img/clients/client-1.jpg" /></a> </div>
           <div class="four columns item"> <a href="#"><img src="images/img/clients/client-2.jpg" /></a> </div>
           <div class="four columns item"> <a href="#"><img src="images/img/clients/client-3.jpg" /></a> </div>
           <div class="four columns item"> <a href="#"><img src="images/img/clients/client-4.jpg" /></a> </div>
          </li><!-- End slide -->
        </ul>
      
       </div><!-- End slidewrap -->
     </div><!-- End features-clients -->
     
</div>