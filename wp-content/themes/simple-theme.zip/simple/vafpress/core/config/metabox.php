<?php

return array(

	////////////////////////////////
	// Main Metabox Configuration //
	////////////////////////////////

	/**
	 * Will always load option values from option.php/xml default values, not DB,
	 * so you can play with the option.php/xml freely.
	 */
	'dev_mode'          => false,

);

/**
 * EOF
 */