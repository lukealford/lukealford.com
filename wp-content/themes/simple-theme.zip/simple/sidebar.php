<div class="five columns sidebar bottom-3">
   
   <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) :  endif; ?>
   
<div class="clearfix"></div>
</div>